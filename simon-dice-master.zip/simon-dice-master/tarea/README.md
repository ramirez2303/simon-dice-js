# Tarea de la clase 10

## Implementar bootstrap en los ejercicios anteriores 
* En los formularios que crearon para calcular edades, integrantes, etc.
darles estilo con Bootstrap.
* Instalar bootstrap con NPM.

## Hacer un "memotest"
Ejemplo: https://www.juegosdememoriagratis.com/adultos/01-simples/s-frutas.html

Condiciones:
* Hacerlo en un repositorio nuevo
* Usar bootstrap (con NPM) -- NO SUBIR node_modules
* Las posiciones de cada "carta" tienen que ser random en cada juego.
* Mostrar cuánto tiempo va de juego.
* Mostrar cuántos intentos hay hasta el momento.
