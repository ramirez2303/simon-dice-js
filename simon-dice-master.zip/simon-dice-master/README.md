# simon-dice
Ejemplo de juego simon dice para r/Argentina programa

## Instalación

Correr
`npm install`
